
ShopLedger - Full-stack monorepo (frontend + backend)

Backend: Node/Express/MongoDB (Mongoose) - includes ApiResponse, ApiError, subscription checks, role middleware, PDF invoice generation via PDFKit, and Nodemailer email send.
Frontend: React + Vite + Tailwind - includes pages for auth, products, sales, purchases, invoices, and reports.

See backend/.env.example and frontend/.env.example for configuration.
